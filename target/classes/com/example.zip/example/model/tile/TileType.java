package com.example.model.tile;

public enum TileType {
    Wall,
    Empty,
    Dot,
    Energizer
}

package com.example.model.entity.enemy;

public enum GhostMode {
    Chase,
    Scatter,
    Frightened,
    Eaten,
    InPen,
    Spawn
}

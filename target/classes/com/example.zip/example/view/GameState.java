package com.example.view;

public enum GameState {
    START_MENU,
    READY,
    PAUSED,
    RUN,
    POST_MENU
}
